# 🌐 Web Basic Tutorial

웹 개발 기초를 위한 HTML & CSS 예제 코드 모음집

## 📚 Contents

- HTML 기초 문법 및 태그 예제
- CSS 기초 스타일링 가이드
- 실습 프로젝트: 자기소개 카드 만들기
